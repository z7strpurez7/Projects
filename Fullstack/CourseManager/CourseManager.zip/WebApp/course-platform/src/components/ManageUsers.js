import React from 'react'

const ManageUsers = () => {
  return (
    <div>Coming soon</div>
  )
}

export default ManageUsers