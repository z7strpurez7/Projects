
import CourseList from '../components/CourseList/CourseList';
import Navbar from '../components/Navbar';
function Homepage() {

  return (
    <div>
    <Navbar />
    <CourseList />
    </div>
  );
}

export default Homepage;