﻿namespace CourseManagerAPI.Constants
{
    public class StaticEnrollmentStatus
    {
        public const string ACTIVE = "ACTIVE";
        public const string COMPLETED = "COMPLETED";
        public const string CANCELLED = "cancelled";
    }
}
