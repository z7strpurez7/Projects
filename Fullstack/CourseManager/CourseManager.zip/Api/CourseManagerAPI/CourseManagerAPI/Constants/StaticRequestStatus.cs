﻿namespace CourseManagerAPI.Constants
{
    public static class StaticRequestStatus
    {
        public const string ACCEPTED = "ACCEPTED";
        public const string PENDING = "PENDING";
     
        public const string REJECTED = "REJECTED";
        
    }
}
