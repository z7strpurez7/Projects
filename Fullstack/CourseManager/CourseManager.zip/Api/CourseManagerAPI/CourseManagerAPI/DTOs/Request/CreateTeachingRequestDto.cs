﻿using CourseManagerAPI.Constants;

namespace CourseManagerAPI.DTOs.Request
{
    public class CreateTeachingRequestDto
    {
     
        public int CourseId { get; set; }
        
      
    }
}
