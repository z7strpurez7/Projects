﻿namespace CourseManagerAPI.DTOs.Auth
{
    public class MeDto
    {
        public string Token { get; set; }
    }
}
