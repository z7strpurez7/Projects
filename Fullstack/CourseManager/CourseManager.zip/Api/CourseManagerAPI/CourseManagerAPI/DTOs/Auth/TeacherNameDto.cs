﻿namespace CourseManagerAPI.DTOs.Auth
{
    public class TeacherNameDto
    {
        public string TeacherId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
